Persistent uploads. Keep outside release replacement; back up separately.
