Open docs/manuals/HyperZone生产部署指导手册.html.
Install Node.js 22 and PostgreSQL 16; run npm ci --omit=dev on the target host.
No secrets, accounts or business data are included. Production values and source acceptance remain pending.
